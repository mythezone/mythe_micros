#-*- coding:utf-8 -*-

def mysum(*values):
    s=0
    for v in values:
        i=int(v)
        s+=i
    print(s)

def output():
    print("http://someurl")
