#-*- coding:utf-8 -*-
from .mytest import mysum,output
