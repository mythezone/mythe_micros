from setuptools import setup,find_packages

setup(
    name= "mythe_micros",
    version = "0.0.0",
    keywords=("pip","micro","service"),
    description=("Easy Micro Service Library"),
    long_description=("To be fill."),
    license="MIT Licence",

    url="",
    author="Mythezone",
    author_email="125616515@qq.com",

    packages=find_packages(),
    include_package_data=True,
    install_requires=[]

)